<?php
// userlogin.php - DJ Gaming VIP · User Authentication API (FINAL FIXED VERSION)
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Set timezone to match your server (adjust as needed)
date_default_timezone_set('Asia/Kolkata'); // Change to your timezone

$host = "localhost";
$dbname = "djgaming_devpro";
$username = "djgaming_devpro";
$password = "DL3CAY8608";

// Connect to database
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    
    // Set MySQL timezone to match PHP
    $pdo->exec("SET time_zone = '+05:30'"); // For IST, adjust as needed
} catch (PDOException $e) {
    echo json_encode(["success" => false, "message" => "Database connection failed: " . $e->getMessage()]);
    exit;
}

// Get POST data from Sketchware (form data)
$keyAuth = isset($_POST['keyAuth']) ? strtoupper(trim($_POST['keyAuth'])) : '';
$deviceID = isset($_POST['deviceID']) ? trim($_POST['deviceID']) : '';

if (empty($keyAuth)) {
    echo json_encode(["success" => false, "message" => "KeyAuth required"]);
    exit;
}

if (empty($deviceID)) {
    echo json_encode(["success" => false, "message" => "Device ID required"]);
    exit;
}

try {
    // Check if KeyAuth exists
    $stmt = $pdo->prepare("SELECT * FROM users WHERE KeyAuth = :keyAuth");
    $stmt->bindParam(':keyAuth', $keyAuth);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        echo json_encode(["success" => false, "message" => "Invalid KeyAuth"]);
        exit;
    }

    // Check if account is active
    if ($user['status'] !== 'active') {
        echo json_encode(["success" => false, "message" => "Your account is not active. Please contact support."]);
        exit;
    }

    // Check if account has expired
    $isExpired = false;
    $expiryDate = null;
    
    if ($user['validUntil'] !== null && $user['validUntil'] !== '0000-00-00 00:00:00') {
        try {
            $validUntil = new DateTime($user['validUntil']);
            $now = new DateTime();
            
            // Remove microseconds for accurate comparison
            $validUntil->setTime($validUntil->format('H'), $validUntil->format('i'), $validUntil->format('s'));
            $now->setTime($now->format('H'), $now->format('i'), $now->format('s'));
            
            // If expiration date is in the past
            if ($validUntil < $now) {
                $isExpired = true;
                $expiryDate = $user['validUntil'];
                
                // Auto-update status to inactive if expired
                $updateStmt = $pdo->prepare("UPDATE users SET status = 'inactive' WHERE KeyAuth = :keyAuth");
                $updateStmt->bindParam(':keyAuth', $keyAuth);
                $updateStmt->execute();
            }
        } catch (Exception $e) {
            // If date parsing fails, treat as not expired
            error_log("Date parsing error for user {$keyAuth}: " . $e->getMessage());
        }
    }
    
    if ($isExpired) {
        echo json_encode([
            "success" => false, 
            "message" => "Your account has expired on " . date('Y-m-d H:i', strtotime($expiryDate))
        ]);
        exit;
    }

    // Access type checking logic - UPDATED for 'single' and 'unlimited'
    $access = $user['access'] ?? 'single'; // Default to 'single' if not set
    
    if ($access === 'single') {
        // Single device mode - check if already used on another device
        if (!empty($user['deviceID']) && $user['deviceID'] !== $deviceID) {
            echo json_encode([
                "success" => false, 
                "message" => "Account already logged in on another device. Single device license.",
                "access" => "single",
                "locked_device" => substr($user['deviceID'], 0, 10) . '...'
            ]);
            exit;
        }
        
        // Update device ID for single device mode (only if not already set)
        if (empty($user['deviceID'])) {
            $updateStmt = $pdo->prepare("UPDATE users SET deviceID = :deviceID WHERE KeyAuth = :keyAuth");
            $updateStmt->bindParam(':deviceID', $deviceID);
            $updateStmt->bindParam(':keyAuth', $keyAuth);
            $updateStmt->execute();
        }
        
    } else if ($access === 'unlimited') {
        // Unlimited device mode - store comma-separated device IDs
        $currentDevices = !empty($user['deviceID']) ? explode(',', $user['deviceID']) : [];
        
        if (!in_array($deviceID, $currentDevices)) {
            // Add new device to the list (limit to last 20 devices to prevent overflow)
            array_push($currentDevices, $deviceID);
            $currentDevices = array_slice($currentDevices, -20); // Keep only last 20
            $updatedDevices = implode(',', $currentDevices);
            
            $updateStmt = $pdo->prepare("UPDATE users SET deviceID = :deviceID WHERE KeyAuth = :keyAuth");
            $updateStmt->bindParam(':deviceID', $updatedDevices);
            $updateStmt->bindParam(':keyAuth', $keyAuth);
            $updateStmt->execute();
        }
    }

    // Calculate remaining time for response
    $remainingTime = null;
    if ($user['validUntil'] !== null && $user['validUntil'] !== '0000-00-00 00:00:00') {
        try {
            $validUntil = new DateTime($user['validUntil']);
            $now = new DateTime();
            
            if ($validUntil > $now) {
                $interval = $now->diff($validUntil);
                
                $remainingTime = [
                    'days' => $interval->d,
                    'hours' => $interval->h,
                    'minutes' => $interval->i,
                    'seconds' => $interval->s,
                    'total_minutes' => ($interval->days * 24 * 60) + ($interval->h * 60) + $interval->i,
                    'total_hours' => ($interval->days * 24) + $interval->h + ($interval->i / 60),
                    'formatted' => formatRemainingTime($interval)
                ];
            }
        } catch (Exception $e) {
            error_log("Remaining time calculation error: " . $e->getMessage());
        }
    }
    
    // Format access for response - UPDATED for 'single' and 'unlimited'
    $accessDisplay = ($access === 'unlimited') ? 'unlimited' : 'single';
    
    // Get device info for response (masked for security)
    $deviceInfo = $user['deviceID'];
    if ($access === 'unlimited' && !empty($deviceInfo)) {
        $deviceCount = count(explode(',', $deviceInfo));
        $deviceInfo = "$deviceCount device(s) registered";
    } elseif (!empty($deviceInfo) && $access === 'single') {
        $deviceInfo = substr($deviceInfo, 0, 10) . '...';
    } else {
        $deviceInfo = 'Not registered';
    }
    
    // Get current server time for sync
    $serverTime = new DateTime();
    
    // Return success with user data
    $response = [
        "success" => true,
        "user" => [
            "id" => $user['id'],
            "keyAuth" => $user['KeyAuth'],
            "status" => $user['status'],
            "access" => $access,
            "access_type" => $accessDisplay,
            "validUntil" => $user['validUntil'],
            "registered_date" => $user['registeredDate'],
            "device_id" => $deviceInfo
        ],
        "message" => "Login successful",
        "access" => $access,
        "access_display" => $accessDisplay,
        "server_time" => $serverTime->format('Y-m-d H:i:s'),
        "remaining_time" => $remainingTime
    ];
    
    // Add expiry warning if less than 7 days remaining
    if ($remainingTime && $remainingTime['days'] < 7 && $remainingTime['days'] >= 0) {
        $response['warning'] = "Your subscription expires in " . $remainingTime['days'] . " days. Please renew soon!";
    }
    
    echo json_encode($response);

} catch (PDOException $e) {
    echo json_encode([
        "success" => false, 
        "message" => "Database error: " . $e->getMessage()
    ]);
}

// Helper function to format remaining time nicely
function formatRemainingTime($interval) {
    if ($interval->days > 0) {
        if ($interval->days == 1) {
            return "1 day";
        }
        return $interval->days . " days";
    }
    if ($interval->h > 0) {
        if ($interval->h == 1) {
            return "1 hour";
        }
        return $interval->h . " hours";
    }
    if ($interval->i > 0) {
        if ($interval->i == 1) {
            return "1 minute";
        }
        return $interval->i . " minutes";
    }
    if ($interval->s > 0) {
        return "Less than a minute";
    }
    return "Expired";
}
?>