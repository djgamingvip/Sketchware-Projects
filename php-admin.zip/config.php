<?php
// config.php - Unified Configuration for DJ Gaming VIP System

// Check if session is already started before starting it
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$host = "localhost";
$dbname = "djgaming_devpro";
$username = "djgaming_devpro";
$password = "DL3CAY8608";

try {
    // PDO Connection
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

    // Create users table only
    $sql_users = "CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        KeyAuth VARCHAR(8) NOT NULL UNIQUE,
        deviceID TEXT DEFAULT NULL,
        status ENUM('active', 'inactive') DEFAULT 'active',
        access ENUM('single', 'unlimited') DEFAULT 'single',
        validUntil DATETIME DEFAULT NULL,
        registeredDate DATETIME DEFAULT CURRENT_TIMESTAMP
    )";
    $pdo->exec($sql_users);

} catch(PDOException $e) {
    die("Database Connection failed: " . $e->getMessage());
}

// MySQLi Connection (for backward compatibility)
$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    die("MySQLi Connection failed: " . $conn->connect_error);
}
$conn->set_charset("utf8mb4");

// Helper function to get remaining time
function getRemainingTime($validUntil) {
    if (!$validUntil || $validUntil === '0000-00-00 00:00:00') {
        return null;
    }
    
    try {
        $validDate = new DateTime($validUntil);
        $now = new DateTime();
        
        if ($validDate <= $now) {
            return ['expired' => true, 'text' => 'Expired'];
        }
        
        $interval = $now->diff($validDate);
        $days = $interval->days;
        $hours = $interval->h;
        $minutes = $interval->i;
        
        if ($days > 0) {
            return ['expired' => false, 'text' => "{$days}d {$hours}h"];
        }
        if ($hours > 0) {
            return ['expired' => false, 'text' => "{$hours}h {$minutes}m"];
        }
        if ($minutes > 0) {
            return ['expired' => false, 'text' => "{$minutes}m"];
        }
        
        return ['expired' => true, 'text' => 'Expired'];
    } catch (Exception $e) {
        return null;
    }
}

// Helper function to generate a random key
function generateKey($length = 8) {
    $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    $key = '';
    for ($i = 0; $i < $length; $i++) {
        $key .= $chars[random_int(0, strlen($chars) - 1)];
    }
    return $key;
}

// Helper function to validate if a key exists
function keyExists($pdo, $key) {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE KeyAuth = ?");
    $stmt->execute([$key]);
    return $stmt->fetchColumn() > 0;
}
?>