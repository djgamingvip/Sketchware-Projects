<?php
// admin.php - DJ Gaming VIP · Key Auth Admin Panel
require_once 'config.php';

date_default_timezone_set('Asia/Kolkata');

$admin_user = "admin";
$admin_pass = "djgamingvip1010";

// --- Auth ---
if (isset($_POST['login'])) {
    if ($_POST['username'] === $admin_user && $_POST['password'] === $admin_pass) {
        $_SESSION['admin'] = true;
        header("Location: admin.php");
        exit();
    } else {
        $error = "Invalid credentials. Access denied.";
    }
}

if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: admin.php");
    exit();
}

if (isset($_SESSION['admin'])) {

    // Create Key
    if (isset($_POST['create_user'])) {
        try {
            $keyAuth = strtoupper(trim($_POST['keyAuth']));
            $access  = $_POST['access'];
            $validUntil = !empty($_POST['validUntil']) ? $_POST['validUntil'] : null;
            $status  = $_POST['status'];

            if (strlen($keyAuth) != 8) {
                $error = "Key must be exactly 8 characters long.";
            } else {
                $stmt = $pdo->prepare("INSERT INTO users (KeyAuth, access, validUntil, status, registeredDate) VALUES (?, ?, ?, ?, NOW())");
                $stmt->execute([$keyAuth, $access, $validUntil, $status]);
                header("Location: admin.php?created=1");
                exit();
            }
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) {
                $error = "Key already exists. Generate a new one.";
            } else {
                $error = "Error: " . $e->getMessage();
            }
        }
    }

    // Update Key
    if (isset($_POST['update_user'])) {
        try {
            $id = (int)$_POST['user_id'];
            $access = $_POST['access'];
            $validUntil = !empty($_POST['validUntil']) ? $_POST['validUntil'] : null;
            $status = $_POST['status'];
            $reset_device = isset($_POST['reset_device']) ? 1 : 0;

            if ($reset_device) {
                $stmt = $pdo->prepare("UPDATE users SET access=?, validUntil=?, status=?, deviceID=NULL WHERE id=?");
                $stmt->execute([$access, $validUntil, $status, $id]);
            } else {
                $stmt = $pdo->prepare("UPDATE users SET access=?, validUntil=?, status=? WHERE id=?");
                $stmt->execute([$access, $validUntil, $status, $id]);
            }
            header("Location: admin.php?updated=1");
            exit();
        } catch (PDOException $e) {
            $error = "Error: " . $e->getMessage();
        }
    }

    // Delete Key
    if (isset($_GET['delete'])) {
        try {
            $stmt = $pdo->prepare("DELETE FROM users WHERE id=?");
            $stmt->execute([(int)$_GET['delete']]);
            header("Location: admin.php?deleted=1");
            exit();
        } catch (PDOException $e) {
            $error = "Error: " . $e->getMessage();
        }
    }

    // Toggle Status
    if (isset($_GET['toggle'])) {
        try {
            $stmt = $pdo->prepare("SELECT status FROM users WHERE id=?");
            $stmt->execute([(int)$_GET['toggle']]);
            $u = $stmt->fetch();
            $newStatus = ($u['status'] === 'active') ? 'inactive' : 'active';
            $stmt2 = $pdo->prepare("UPDATE users SET status=? WHERE id=?");
            $stmt2->execute([$newStatus, (int)$_GET['toggle']]);
            header("Location: admin.php?status_updated=1");
            exit();
        } catch (PDOException $e) {
            $error = "Error: " . $e->getMessage();
        }
    }

    $users = $pdo->query("SELECT * FROM users ORDER BY id DESC")->fetchAll();

    $total = count($users);
    $active = 0;
    $expired = 0;
    $inactive_count = 0;
    $unlimitedCount = 0;
    $singleCount = 0;
    $now = new DateTime();

    foreach ($users as $u) {
        if ($u['access'] === 'unlimited') $unlimitedCount++;
        else $singleCount++;

        if ($u['status'] === 'active') {
            if ($u['validUntil'] && $u['validUntil'] !== '0000-00-00 00:00:00') {
                try {
                    $vd = new DateTime($u['validUntil']);
                    if ($vd < $now) $expired++;
                    else $active++;
                } catch (Exception $e) { $active++; }
            } else {
                $active++;
            }
        } else {
            $inactive_count++;
        }
    }
}

function timeRemaining($validUntil) {
    if (!$validUntil || $validUntil === '0000-00-00 00:00:00') return null;
    try {
        $vd  = new DateTime($validUntil);
        $now = new DateTime();
        if ($vd < $now) return ['expired' => true, 'text' => 'Expired'];
        $i = $now->diff($vd);
        if ($i->days > 0) return ['expired' => false, 'text' => "{$i->days}d {$i->h}h"];
        if ($i->h  > 0) return ['expired' => false, 'text' => "{$i->h}h {$i->i}m"];
        if ($i->i  > 0) return ['expired' => false, 'text' => "{$i->i}m"];
        return ['expired' => false, 'text' => '<1m'];
    } catch (Exception $e) { return null; }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>DJ Gaming VIP · Admin Panel</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
/* =========================================================
   RESET & VARIABLES
   ========================================================= */
*, *::before, *::after { margin: 0; padding: 0; box-sizing: border-box; }

:root {
    /* Brand */
    --red:          #e02020;
    --red-dark:     #b91c1c;
    --red-light:    #ef4444;
    --red-soft:     #fff1f1;
    --red-border:   #fecaca;
    --red-glow:     rgba(224, 32, 32, 0.15);

    /* Neutrals */
    --white:        #ffffff;
    --bg:           #f7f8fa;
    --bg-card:      #ffffff;
    --bg-input:     #f9fafb;
    --bg-hover:     #f1f5f9;
    --border:       #e5e7eb;
    --border-focus: #e02020;

    /* Text */
    --text-900:     #111827;
    --text-700:     #374151;
    --text-500:     #6b7280;
    --text-400:     #9ca3af;

    /* Semantic */
    --green:        #16a34a;
    --green-soft:   #dcfce7;
    --green-border: #bbf7d0;
    --amber:        #d97706;
    --amber-soft:   #fef3c7;
    --amber-border: #fde68a;
    --blue:         #2563eb;
    --blue-soft:    #dbeafe;
    --blue-border:  #bfdbfe;
    --purple:       #7c3aed;
    --purple-soft:  #ede9fe;
    --purple-border:#ddd6fe;

    /* Misc */
    --radius-xs:    6px;
    --radius-sm:    8px;
    --radius-md:    12px;
    --radius-lg:    16px;
    --shadow-xs:    0 1px 2px rgba(0,0,0,.05);
    --shadow-sm:    0 1px 4px rgba(0,0,0,.07), 0 1px 2px rgba(0,0,0,.05);
    --shadow-md:    0 4px 12px rgba(0,0,0,.07), 0 2px 4px rgba(0,0,0,.04);
    --shadow-lg:    0 10px 30px rgba(0,0,0,.08), 0 4px 8px rgba(0,0,0,.04);
    --transition:   all .2s cubic-bezier(.4,0,.2,1);
    --sidebar-w:    256px;
}

body {
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
    background: var(--bg);
    color: var(--text-900);
    min-height: 100vh;
    overflow-x: hidden;
    line-height: 1.6;
    -webkit-font-smoothing: antialiased;
}

::-webkit-scrollbar { width: 5px; height: 5px; }
::-webkit-scrollbar-track { background: var(--bg); }
::-webkit-scrollbar-thumb { background: var(--red-border); border-radius: 10px; }
::-webkit-scrollbar-thumb:hover { background: var(--red); }

/* =========================================================
   LOGIN PAGE
   ========================================================= */
.login-page {
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 24px;
    background: linear-gradient(135deg, #fff5f5 0%, #fef2f2 50%, #fff1f1 100%);
    position: relative;
    overflow: hidden;
}

.login-page::before {
    content: '';
    position: absolute;
    top: -120px; right: -120px;
    width: 400px; height: 400px;
    border-radius: 50%;
    background: radial-gradient(circle, rgba(224,32,32,.08) 0%, transparent 70%);
    pointer-events: none;
}

.login-page::after {
    content: '';
    position: absolute;
    bottom: -80px; left: -80px;
    width: 300px; height: 300px;
    border-radius: 50%;
    background: radial-gradient(circle, rgba(224,32,32,.05) 0%, transparent 70%);
    pointer-events: none;
}

.login-card {
    width: 100%;
    max-width: 420px;
    background: var(--white);
    border-radius: var(--radius-lg);
    box-shadow: var(--shadow-lg), 0 0 0 1px rgba(224,32,32,.06);
    padding: 48px 40px 40px;
    position: relative;
    z-index: 1;
}

.login-card::before {
    content: '';
    position: absolute;
    top: 0; left: 10%; right: 10%;
    height: 3px;
    background: linear-gradient(90deg, transparent, var(--red), transparent);
    border-radius: 0 0 4px 4px;
}

.login-logo {
    display: flex;
    flex-direction: column;
    align-items: center;
    margin-bottom: 32px;
}

.login-logo .icon-wrap {
    width: 68px; height: 68px;
    background: var(--red-soft);
    border: 2px solid var(--red-border);
    border-radius: var(--radius-md);
    display: flex; align-items: center; justify-content: center;
    font-size: 28px;
    color: var(--red);
    margin-bottom: 16px;
    box-shadow: 0 4px 16px var(--red-glow);
}

.login-logo h1 {
    font-size: 22px;
    font-weight: 800;
    color: var(--text-900);
    letter-spacing: -.3px;
}

.login-logo h1 span { color: var(--red); }

.login-logo p {
    font-size: 13px;
    color: var(--text-400);
    margin-top: 4px;
    font-weight: 400;
}

.login-error {
    display: flex;
    align-items: center;
    gap: 10px;
    background: var(--red-soft);
    border: 1px solid var(--red-border);
    border-left: 3px solid var(--red);
    border-radius: var(--radius-sm);
    padding: 12px 14px;
    color: var(--red-dark);
    font-size: 13.5px;
    font-weight: 500;
    margin-bottom: 24px;
}

.lbl {
    display: block;
    font-size: 12px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: .5px;
    color: var(--text-500);
    margin-bottom: 6px;
}

.input-group {
    position: relative;
    margin-bottom: 18px;
}

.input-group i {
    position: absolute;
    left: 14px; top: 50%;
    transform: translateY(-50%);
    color: var(--text-400);
    font-size: 14px;
    pointer-events: none;
}

.input-group input {
    width: 100%;
    padding: 11px 14px 11px 42px;
    border: 1.5px solid var(--border);
    border-radius: var(--radius-sm);
    font-family: 'Inter', sans-serif;
    font-size: 14px;
    color: var(--text-900);
    background: var(--bg-input);
    outline: none;
    transition: var(--transition);
}

.input-group input:focus {
    border-color: var(--red);
    background: var(--white);
    box-shadow: 0 0 0 3px var(--red-glow);
}

.input-group input::placeholder { color: var(--text-400); }

.btn-login {
    width: 100%;
    padding: 13px;
    background: linear-gradient(135deg, var(--red-dark), var(--red));
    border: none;
    border-radius: var(--radius-sm);
    color: #fff;
    font-family: 'Inter', sans-serif;
    font-size: 15px;
    font-weight: 700;
    cursor: pointer;
    transition: var(--transition);
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    box-shadow: 0 4px 16px var(--red-glow);
    margin-top: 8px;
}

.btn-login:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 24px var(--red-glow);
}

.btn-login:active { transform: translateY(0); }

/* =========================================================
   ADMIN LAYOUT — SIDEBAR
   ========================================================= */
.admin-wrapper { display: flex; min-height: 100vh; }

.sidebar {
    width: var(--sidebar-w);
    background: var(--white);
    border-right: 1px solid var(--border);
    display: flex;
    flex-direction: column;
    position: fixed;
    top: 0; left: 0; bottom: 0;
    z-index: 200;
    transition: transform .3s ease;
    box-shadow: var(--shadow-sm);
}

.sidebar-brand {
    padding: 20px 20px 16px;
    border-bottom: 1px solid var(--border);
}

.brand-inner {
    display: flex;
    align-items: center;
    gap: 11px;
}

.brand-icon {
    width: 40px; height: 40px;
    background: var(--red-soft);
    border: 1.5px solid var(--red-border);
    border-radius: var(--radius-sm);
    display: flex; align-items: center; justify-content: center;
    color: var(--red);
    font-size: 17px;
    flex-shrink: 0;
}

.brand-text h2 {
    font-size: 15px;
    font-weight: 800;
    line-height: 1.2;
    color: var(--text-900);
    letter-spacing: -.2px;
}

.brand-text span {
    font-size: 10px;
    font-weight: 600;
    color: var(--red);
    text-transform: uppercase;
    letter-spacing: 1.5px;
}

.sidebar-nav {
    flex: 1;
    padding: 12px 10px;
    overflow-y: auto;
}

.nav-section-label {
    font-size: 10px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 1.4px;
    color: var(--text-400);
    padding: 12px 10px 5px;
}

.nav-item {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 9px 12px;
    border-radius: var(--radius-sm);
    color: var(--text-500);
    font-size: 13.5px;
    font-weight: 500;
    cursor: pointer;
    transition: var(--transition);
    border: 1px solid transparent;
    margin-bottom: 2px;
    text-decoration: none;
}

.nav-item i { width: 17px; text-align: center; font-size: 14px; }

.nav-item:hover {
    background: var(--bg-hover);
    color: var(--text-900);
}

.nav-item.active {
    background: var(--red-soft);
    border-color: var(--red-border);
    color: var(--red);
    font-weight: 600;
}

.nav-item .nav-badge {
    margin-left: auto;
    background: var(--red);
    color: #fff;
    font-size: 10px;
    font-weight: 700;
    padding: 1px 7px;
    border-radius: 20px;
    min-width: 20px;
    text-align: center;
}

.sidebar-footer {
    padding: 12px 10px 16px;
    border-top: 1px solid var(--border);
}

.admin-pill {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 10px 12px;
    background: var(--bg);
    border: 1px solid var(--border);
    border-radius: var(--radius-sm);
}

.admin-avatar {
    width: 32px; height: 32px;
    background: linear-gradient(135deg, var(--red-dark), var(--red));
    border-radius: 8px;
    display: flex; align-items: center; justify-content: center;
    font-size: 13px;
    font-weight: 800;
    color: #fff;
    flex-shrink: 0;
}

.admin-info strong { display: block; font-size: 12.5px; color: var(--text-900); }
.admin-info span   { font-size: 11px; color: var(--text-400); }

.logout-btn {
    margin-left: auto;
    background: none;
    border: none;
    color: var(--text-400);
    font-size: 14px;
    cursor: pointer;
    padding: 5px 7px;
    border-radius: 6px;
    transition: var(--transition);
}

.logout-btn:hover { color: var(--red); background: var(--red-soft); }

/* =========================================================
   MAIN CONTENT
   ========================================================= */
.main-content {
    margin-left: var(--sidebar-w);
    flex: 1;
    min-height: 100vh;
    display: flex;
    flex-direction: column;
}

/* =========================================================
   TOPBAR
   ========================================================= */
.topbar {
    background: var(--white);
    border-bottom: 1px solid var(--border);
    padding: 14px 28px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    position: sticky;
    top: 0;
    z-index: 100;
    box-shadow: var(--shadow-xs);
}

.topbar-left { display: flex; align-items: center; gap: 14px; }

.menu-toggle {
    display: none;
    background: none;
    border: none;
    color: var(--text-500);
    font-size: 20px;
    cursor: pointer;
}

.page-title {
    font-size: 18px;
    font-weight: 700;
    color: var(--text-900);
}

.page-title span { color: var(--red); }

.topbar-right { display: flex; align-items: center; gap: 10px; }

.status-pill {
    display: flex;
    align-items: center;
    gap: 7px;
    font-size: 12px;
    color: var(--text-500);
    background: var(--bg);
    border: 1px solid var(--border);
    padding: 5px 14px;
    border-radius: 20px;
    font-weight: 500;
}

.status-pill .dot {
    width: 7px; height: 7px;
    border-radius: 50%;
    background: var(--green);
    animation: blink 2s infinite;
}

@keyframes blink { 0%, 100% { opacity: 1; } 50% { opacity: .3; } }

/* =========================================================
   CONTENT AREA
   ========================================================= */
.content-area { padding: 24px 28px; flex: 1; }

/* =========================================================
   ALERT
   ========================================================= */
.alert {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 12px 16px;
    border-radius: var(--radius-sm);
    font-size: 13.5px;
    font-weight: 500;
    margin-bottom: 20px;
    border-left: 3px solid;
}

.alert-success { background: var(--green-soft); border-color: var(--green); color: #166534; }
.alert-danger  { background: var(--red-soft);   border-color: var(--red);   color: var(--red-dark); }

/* =========================================================
   STAT CARDS
   ========================================================= */
.stats-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 16px;
    margin-bottom: 24px;
}

.stat-card {
    background: var(--white);
    border: 1px solid var(--border);
    border-radius: var(--radius-md);
    padding: 20px 22px;
    transition: var(--transition);
    box-shadow: var(--shadow-sm);
}

.stat-card:hover {
    box-shadow: var(--shadow-md);
    transform: translateY(-2px);
    border-color: var(--red-border);
}

.stat-icon {
    width: 42px; height: 42px;
    border-radius: 10px;
    display: flex; align-items: center; justify-content: center;
    font-size: 17px;
    margin-bottom: 14px;
}

.si-red    { background: var(--red-soft);    color: var(--red); }
.si-green  { background: var(--green-soft);  color: var(--green); }
.si-amber  { background: var(--amber-soft);  color: var(--amber); }
.si-blue   { background: var(--blue-soft);   color: var(--blue); }
.si-purple { background: var(--purple-soft); color: var(--purple); }

.stat-num   { font-size: 28px; font-weight: 800; line-height: 1; color: var(--text-900); }
.stat-label { font-size: 12px; color: var(--text-500); font-weight: 500; margin-top: 4px; text-transform: uppercase; letter-spacing: .4px; }

/* =========================================================
   PANEL / CARD
   ========================================================= */
.panel {
    background: var(--white);
    border: 1px solid var(--border);
    border-radius: var(--radius-md);
    overflow: hidden;
    margin-bottom: 20px;
    box-shadow: var(--shadow-sm);
}

.panel-header {
    padding: 15px 22px;
    border-bottom: 1px solid var(--border);
    display: flex;
    align-items: center;
    justify-content: space-between;
    background: var(--white);
}

.panel-title {
    display: flex;
    align-items: center;
    gap: 9px;
    font-size: 14.5px;
    font-weight: 700;
    color: var(--text-900);
}

.panel-title i { color: var(--red); font-size: 15px; }

.panel-body { padding: 22px; }

/* =========================================================
   BUTTONS
   ========================================================= */
.btn {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 8px 16px;
    border: none;
    border-radius: var(--radius-sm);
    font-family: 'Inter', sans-serif;
    font-size: 13px;
    font-weight: 600;
    cursor: pointer;
    transition: var(--transition);
    text-decoration: none;
}

.btn-primary {
    background: var(--red);
    color: #fff;
    box-shadow: 0 2px 10px var(--red-glow);
}

.btn-primary:hover {
    background: var(--red-dark);
    transform: translateY(-1px);
    box-shadow: 0 4px 16px var(--red-glow);
}

.btn-outline {
    background: var(--white);
    color: var(--text-700);
    border: 1.5px solid var(--border);
}

.btn-outline:hover { background: var(--bg-hover); border-color: var(--text-400); }

.btn-sm { padding: 5px 11px; font-size: 12px; }
.btn-xs { padding: 4px 8px;  font-size: 11px; }
.btn-full { width: 100%; justify-content: center; padding: 12px; font-size: 14px; }

/* =========================================================
   FORM ELEMENTS
   ========================================================= */
.form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
.form-grid .span2 { grid-column: 1 / -1; }

.fg { margin-bottom: 16px; }
.fg label { display: block; font-size: 12px; font-weight: 600; color: var(--text-500); text-transform: uppercase; letter-spacing: .4px; margin-bottom: 5px; }

.fg input,
.fg select,
.fg textarea {
    width: 100%;
    padding: 10px 13px;
    border: 1.5px solid var(--border);
    border-radius: var(--radius-sm);
    font-family: 'Inter', sans-serif;
    font-size: 13.5px;
    color: var(--text-900);
    background: var(--bg-input);
    outline: none;
    transition: var(--transition);
}

.fg input:focus,
.fg select:focus,
.fg textarea:focus {
    border-color: var(--red);
    background: var(--white);
    box-shadow: 0 0 0 3px var(--red-glow);
}

.fg input::placeholder { color: var(--text-400); }
.fg .hint { font-size: 11px; color: var(--text-400); margin-top: 4px; }
.fg .key-input { font-family: 'Courier New', monospace; letter-spacing: 2.5px; font-size: 16px !important; text-transform: uppercase; }

/* =========================================================
   KEY GENERATOR
   ========================================================= */
.key-gen {
    display: flex;
    gap: 8px;
    align-items: center;
    margin-bottom: 14px;
}

.key-gen .key-display {
    flex: 1;
    background: var(--red-soft);
    border: 1.5px solid var(--red-border);
    border-radius: var(--radius-sm);
    padding: 11px 16px;
    font-family: 'Courier New', monospace;
    font-size: 20px;
    font-weight: 700;
    color: var(--red);
    letter-spacing: 3px;
    text-align: center;
    min-width: 0;
    cursor: default;
}

.icon-btn {
    width: 42px; height: 42px;
    display: flex; align-items: center; justify-content: center;
    background: var(--white);
    border: 1.5px solid var(--border);
    border-radius: var(--radius-sm);
    color: var(--text-500);
    cursor: pointer;
    transition: var(--transition);
    flex-shrink: 0;
    font-size: 15px;
}

.icon-btn:hover { border-color: var(--red); color: var(--red); background: var(--red-soft); }

/* =========================================================
   TABLE
   ========================================================= */
.table-wrap { overflow-x: auto; }

table { width: 100%; border-collapse: collapse; font-size: 13px; }

thead th {
    padding: 10px 14px;
    text-align: left;
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: .5px;
    color: var(--text-500);
    border-bottom: 1.5px solid var(--border);
    background: var(--bg);
    white-space: nowrap;
}

tbody td {
    padding: 11px 14px;
    border-bottom: 1px solid var(--border);
    color: var(--text-700);
    vertical-align: middle;
}

tbody tr:hover td { background: #fff9f9; }
tbody tr:last-child td { border-bottom: none; }

.key-cell {
    font-family: 'Courier New', monospace;
    font-weight: 700;
    color: var(--red);
    letter-spacing: 1.5px;
    cursor: pointer;
    font-size: 13.5px;
    transition: var(--transition);
}

.key-cell:hover { color: var(--red-dark); }

/* =========================================================
   BADGES
   ========================================================= */
.badge {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    padding: 3px 10px;
    border-radius: 20px;
    font-size: 11.5px;
    font-weight: 600;
    white-space: nowrap;
}

.badge-active   { background: var(--green-soft);  color: #166534; border: 1px solid var(--green-border); }
.badge-inactive { background: var(--bg);           color: var(--text-500); border: 1px solid var(--border); }
.badge-expired  { background: var(--red-soft);     color: var(--red-dark); border: 1px solid var(--red-border); }
.badge-unlimited{ background: var(--amber-soft);   color: #92400e; border: 1px solid var(--amber-border); }
.badge-single   { background: var(--blue-soft);    color: #1e40af; border: 1px solid var(--blue-border); }
.badge-purple   { background: var(--purple-soft);  color: #5b21b6; border: 1px solid var(--purple-border); }

.dot-sm {
    width: 5px; height: 5px;
    border-radius: 50%;
    display: inline-block;
}

.badge-active   .dot-sm { background: var(--green); }
.badge-inactive .dot-sm { background: var(--text-400); }

/* =========================================================
   ACTION BUTTONS (table row)
   ========================================================= */
.action-group { display: flex; gap: 4px; }

.action-btn {
    width: 30px; height: 30px;
    display: flex; align-items: center; justify-content: center;
    border: 1px solid var(--border);
    border-radius: var(--radius-xs);
    background: var(--white);
    color: var(--text-400);
    cursor: pointer;
    transition: var(--transition);
    font-size: 12px;
}

.action-btn.edit:hover   { border-color: var(--blue-border); color: var(--blue); background: var(--blue-soft); }
.action-btn.toggle:hover { border-color: var(--amber-border); color: var(--amber); background: var(--amber-soft); }
.action-btn.delete:hover { border-color: var(--red-border); color: var(--red); background: var(--red-soft); }

/* =========================================================
   TOOLBAR (search + filter row)
   ========================================================= */
.toolbar {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 14px;
    flex-wrap: wrap;
}

.search-box {
    display: flex;
    align-items: center;
    gap: 8px;
    background: var(--white);
    border: 1.5px solid var(--border);
    border-radius: var(--radius-sm);
    padding: 7px 13px;
    flex: 1;
    max-width: 280px;
    transition: var(--transition);
}

.search-box:focus-within { border-color: var(--red); box-shadow: 0 0 0 3px var(--red-glow); }
.search-box i { color: var(--text-400); font-size: 13px; }

.search-box input {
    background: none; border: none; outline: none;
    color: var(--text-900); font-family: 'Inter', sans-serif;
    font-size: 13px; width: 100%;
}

.search-box input::placeholder { color: var(--text-400); }

.toolbar select {
    background: var(--white);
    border: 1.5px solid var(--border);
    border-radius: var(--radius-sm);
    padding: 7px 12px;
    color: var(--text-700);
    font-family: 'Inter', sans-serif;
    font-size: 13px;
    outline: none;
    cursor: pointer;
    transition: var(--transition);
}

.toolbar select:focus { border-color: var(--red); }
.count-tag { margin-left: auto; font-size: 12px; color: var(--text-400); font-weight: 500; }

/* =========================================================
   MODAL
   ========================================================= */
.overlay {
    position: fixed; inset: 0;
    background: rgba(0,0,0,.35);
    backdrop-filter: blur(3px);
    z-index: 1000;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 20px;
    opacity: 0;
    pointer-events: none;
    transition: opacity .25s ease;
}

.overlay.open { opacity: 1; pointer-events: all; }

.modal {
    background: var(--white);
    border-radius: var(--radius-md);
    max-width: 480px;
    width: 100%;
    box-shadow: var(--shadow-lg);
    transform: translateY(16px) scale(.97);
    transition: transform .25s ease;
    border: 1px solid var(--border);
}

.overlay.open .modal { transform: translateY(0) scale(1); }

.modal-header {
    padding: 18px 22px;
    border-bottom: 1px solid var(--border);
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.modal-header h3 {
    font-size: 16px;
    font-weight: 700;
    display: flex;
    align-items: center;
    gap: 8px;
    color: var(--text-900);
}

.modal-header h3 i { color: var(--red); }

.close-btn {
    background: none; border: none;
    color: var(--text-400);
    font-size: 18px;
    cursor: pointer;
    padding: 2px 6px;
    border-radius: 6px;
    transition: var(--transition);
}

.close-btn:hover { color: var(--red); background: var(--red-soft); transform: rotate(90deg); }

.modal-body { padding: 22px; }
.modal-footer { padding: 14px 22px; border-top: 1px solid var(--border); display: flex; justify-content: flex-end; gap: 8px; background: var(--bg); border-radius: 0 0 var(--radius-md) var(--radius-md); }

/* =========================================================
   CHECKBOX ROW
   ========================================================= */
.check-row {
    display: flex; align-items: center; gap: 8px;
    font-size: 13px; color: var(--text-700);
    cursor: pointer; padding: 6px 0;
}

.check-row input[type="checkbox"] {
    width: 15px; height: 15px;
    accent-color: var(--red);
    cursor: pointer;
}

/* =========================================================
   EMPTY STATE
   ========================================================= */
.empty-state {
    text-align: center; padding: 56px 20px; color: var(--text-400);
}

.empty-state i { font-size: 44px; margin-bottom: 14px; opacity: .3; }
.empty-state h4 { color: var(--text-500); margin-bottom: 5px; font-size: 15px; }
.empty-state p { font-size: 13px; }

/* =========================================================
   TWO-COLUMN CREATE LAYOUT
   ========================================================= */
.create-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }

/* =========================================================
   QUICK STATS LIST
   ========================================================= */
.qs-list { display: flex; flex-direction: column; gap: 0; }

.qs-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 9px 0;
    border-bottom: 1px solid var(--border);
    font-size: 13px;
}

.qs-row:last-child { border-bottom: none; }
.qs-row span:first-child { color: var(--text-500); }
.qs-row span:last-child  { font-weight: 700; color: var(--text-900); }

/* =========================================================
   KEY EXAMPLES
   ========================================================= */
.key-examples { display: flex; flex-direction: column; gap: 8px; }

.key-example-row {
    display: flex; align-items: center; gap: 10px;
}

.key-pill {
    font-family: 'Courier New', monospace;
    font-size: 14.5px;
    font-weight: 700;
    color: var(--red);
    background: var(--red-soft);
    border: 1px solid var(--red-border);
    padding: 7px 16px;
    border-radius: var(--radius-xs);
    letter-spacing: 2.5px;
    flex: 1;
    text-align: center;
}

/* =========================================================
   DIVIDER + SECTION HEADING
   ========================================================= */
.section-divider {
    height: 1px;
    background: var(--border);
    margin: 20px 0;
}

/* =========================================================
   RESPONSIVE
   ========================================================= */
@media (max-width: 1100px) {
    .stats-grid { grid-template-columns: repeat(2, 1fr); }
}

@media (max-width: 768px) {
    .sidebar { transform: translateX(-100%); }
    .sidebar.open { transform: translateX(0); }
    .main-content { margin-left: 0; }
    .menu-toggle { display: block !important; }
    .topbar { padding: 12px 16px; }
    .content-area { padding: 16px; }
    .stats-grid { grid-template-columns: repeat(2, 1fr); gap: 10px; }
    .create-grid { grid-template-columns: 1fr; }
    .form-grid { grid-template-columns: 1fr; }
    .search-box { max-width: 100%; }
    .login-card { padding: 32px 24px 28px; }
}

@media (max-width: 480px) {
    .stats-grid { grid-template-columns: 1fr 1fr; gap: 8px; }
    .stat-num { font-size: 22px; }
}
</style>
</head>
<body>

<?php if (!isset($_SESSION['admin'])): ?>
<!-- ===========================
     LOGIN PAGE
     =========================== -->
<div class="login-page">
    <div class="login-card">
        <div class="login-logo">
            <div class="icon-wrap"><i class="fas fa-gamepad"></i></div>
            <h1>DJ GAMING <span>VIP</span></h1>
            <p>Admin Control Panel</p>
        </div>

        <?php if (isset($error)): ?>
        <div class="login-error">
            <i class="fas fa-exclamation-triangle"></i>
            <?= htmlspecialchars($error) ?>
        </div>
        <?php endif; ?>

        <form method="POST" autocomplete="off">
            <label class="lbl">Username</label>
            <div class="input-group">
                <i class="fas fa-user"></i>
                <input type="text" name="username" placeholder="Enter username" required autofocus>
            </div>

            <label class="lbl">Password</label>
            <div class="input-group">
                <i class="fas fa-lock"></i>
                <input type="password" name="password" placeholder="Enter password" required>
            </div>

            <button type="submit" name="login" class="btn-login">
                <i class="fas fa-sign-in-alt"></i> Sign In to Dashboard
            </button>
        </form>
    </div>
</div>

<?php else: ?>
<!-- ===========================
     ADMIN DASHBOARD
     =========================== -->
<div class="admin-wrapper">

    <!-- SIDEBAR -->
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-brand">
            <div class="brand-inner">
                <div class="brand-icon"><i class="fas fa-gamepad"></i></div>
                <div class="brand-text">
                    <h2>DJ GAMING</h2>
                    <span>VIP Admin Panel</span>
                </div>
            </div>
        </div>

        <nav class="sidebar-nav">
            <div class="nav-section-label">Dashboard</div>
            <a class="nav-item active" data-tab="dashboard" onclick="switchTab('dashboard')">
                <i class="fas fa-th-large"></i> Overview
            </a>

            <div class="nav-section-label">Management</div>
            <a class="nav-item" data-tab="keys" onclick="switchTab('keys')">
                <i class="fas fa-key"></i> All Keys
                <span class="nav-badge"><?= $total ?></span>
            </a>
            <a class="nav-item" data-tab="create" onclick="switchTab('create')">
                <i class="fas fa-plus-circle"></i> Create Key
            </a>
        </nav>

        <div class="sidebar-footer">
            <div class="admin-pill">
                <div class="admin-avatar">A</div>
                <div class="admin-info">
                    <strong>Administrator</strong>
                    <span>Super Admin</span>
                </div>
                <a href="?logout" class="logout-btn" title="Logout"><i class="fas fa-sign-out-alt"></i></a>
            </div>
        </div>
    </aside>

    <!-- MAIN -->
    <div class="main-content">

        <!-- TOPBAR -->
        <header class="topbar">
            <div class="topbar-left">
                <button class="menu-toggle" onclick="document.getElementById('sidebar').classList.toggle('open')">
                    <i class="fas fa-bars"></i>
                </button>
                <div class="page-title" id="pageTitle"><span>#</span> Overview</div>
            </div>
            <div class="topbar-right">
                <div class="status-pill">
                    <span class="dot"></span>
                    System Online
                </div>
            </div>
        </header>

        <!-- CONTENT -->
        <div class="content-area">

            <!-- Alerts -->
            <?php if (isset($_GET['created']) || isset($_GET['updated']) || isset($_GET['deleted']) || isset($_GET['status_updated'])): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> Operation completed successfully!
            </div>
            <?php endif; ?>
            <?php if (isset($error)): ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-triangle"></i> <?= htmlspecialchars($error) ?>
            </div>
            <?php endif; ?>

            <!-- ==============================
                 TAB: DASHBOARD / OVERVIEW
                 ============================== -->
            <div id="tab-dashboard" class="tab-pane active">

                <!-- Stats Row -->
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-icon si-red"><i class="fas fa-key"></i></div>
                        <div class="stat-num"><?= $total ?></div>
                        <div class="stat-label">Total Keys</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon si-green"><i class="fas fa-check-circle"></i></div>
                        <div class="stat-num"><?= $active ?></div>
                        <div class="stat-label">Active</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon si-amber"><i class="fas fa-ban"></i></div>
                        <div class="stat-num"><?= $inactive_count ?></div>
                        <div class="stat-label">Inactive</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon si-blue"><i class="fas fa-clock"></i></div>
                        <div class="stat-num"><?= $expired ?></div>
                        <div class="stat-label">Expired</div>
                    </div>
                </div>

                <!-- Secondary Stats Row -->
                <div class="stats-grid" style="grid-template-columns: repeat(2, 1fr); margin-bottom: 24px;">
                    <div class="stat-card">
                        <div class="stat-icon si-amber"><i class="fas fa-infinity"></i></div>
                        <div class="stat-num" style="color:var(--amber);"><?= $unlimitedCount ?></div>
                        <div class="stat-label">Unlimited Keys</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon si-blue"><i class="fas fa-mobile-alt"></i></div>
                        <div class="stat-num" style="color:var(--blue);"><?= $singleCount ?></div>
                        <div class="stat-label">Single Device Keys</div>
                    </div>
                </div>

                <!-- Recent Keys Table -->
                <div class="panel">
                    <div class="panel-header">
                        <div class="panel-title">
                            <i class="fas fa-clock"></i> Recent Keys
                        </div>
                        <button class="btn btn-outline btn-sm" onclick="switchTab('keys')">
                            <i class="fas fa-arrow-right"></i> View All
                        </button>
                    </div>
                    <div class="panel-body" style="padding:0;">
                        <div class="table-wrap">
                            <table>
                                <thead>
                                    <tr>
                                        <th>Key</th>
                                        <th>Status</th>
                                        <th>Access</th>
                                        <th>Expires</th>
                                        <th>Registered</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php foreach(array_slice($users, 0, 8) as $u):
                                    $tr = timeRemaining($u['validUntil']);
                                ?>
                                    <tr>
                                        <td>
                                            <span class="key-cell" onclick="copyText('<?= htmlspecialchars($u['KeyAuth']) ?>', this)" title="Click to copy">
                                                <?= htmlspecialchars($u['KeyAuth']) ?>
                                            </span>
                                        </td>
                                        <td>
                                            <?php if ($u['status'] === 'active'): ?>
                                            <span class="badge badge-active"><span class="dot-sm"></span> Active</span>
                                            <?php else: ?>
                                            <span class="badge badge-inactive"><span class="dot-sm"></span> Inactive</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if ($u['access'] === 'unlimited'): ?>
                                            <span class="badge badge-unlimited"><i class="fas fa-infinity"></i> Unlimited</span>
                                            <?php else: ?>
                                            <span class="badge badge-single"><i class="fas fa-mobile-alt"></i> Single</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if (!$tr): ?>
                                            <span style="color:var(--text-400);font-size:12px;">Never</span>
                                            <?php elseif ($tr['expired']): ?>
                                            <span class="badge badge-expired"><i class="fas fa-skull"></i> Expired</span>
                                            <?php else: ?>
                                            <span style="font-size:12px;color:var(--text-500);"><?= $tr['text'] ?></span>
                                            <?php endif; ?>
                                        </td>
                                        <td style="font-size:12px;color:var(--text-400);"><?= date('d M Y', strtotime($u['registeredDate'])) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                                <?php if(empty($users)): ?>
                                    <tr><td colspan="5">
                                        <div class="empty-state">
                                            <i class="fas fa-key"></i>
                                            <h4>No keys yet</h4>
                                            <p>Create your first key to get started</p>
                                        </div>
                                    </td></tr>
                                <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div><!-- /tab-dashboard -->

            <!-- ==============================
                 TAB: ALL KEYS
                 ============================== -->
            <div id="tab-keys" class="tab-pane" style="display:none;">
                <div class="panel">
                    <div class="panel-header">
                        <div class="panel-title">
                            <i class="fas fa-key"></i> All Keys
                        </div>
                        <button class="btn btn-primary btn-sm" onclick="switchTab('create')">
                            <i class="fas fa-plus"></i> New Key
                        </button>
                    </div>
                    <div class="panel-body">

                        <div class="toolbar">
                            <div class="search-box">
                                <i class="fas fa-search"></i>
                                <input type="text" id="searchInput" placeholder="Search keys, devices…" onkeyup="filterTable()">
                            </div>
                            <select id="statusFilter" onchange="filterTable()">
                                <option value="">All Status</option>
                                <option value="active">Active</option>
                                <option value="inactive">Inactive</option>
                            </select>
                            <select id="accessFilter" onchange="filterTable()">
                                <option value="">All Access</option>
                                <option value="single">Single Device</option>
                                <option value="unlimited">Unlimited</option>
                            </select>
                            <span class="count-tag" id="tableCount"><?= $total ?> key<?= $total !== 1 ? 's' : '' ?></span>
                        </div>

                        <div class="table-wrap">
                            <table>
                                <thead>
                                    <tr>
                                        <th style="width:36px;">#</th>
                                        <th>Key</th>
                                        <th>Status</th>
                                        <th>Access</th>
                                        <th>Device</th>
                                        <th>Expires</th>
                                        <th>Registered</th>
                                        <th style="text-align:right;">Actions</th>
                                    </tr>
                                </thead>
                                <tbody id="keysBody">
                                <?php foreach($users as $i => $u):
                                    $tr = timeRemaining($u['validUntil']);
                                    $deviceShort = $u['deviceID'] ? (strlen($u['deviceID']) > 16 ? substr($u['deviceID'],0,14).'…' : $u['deviceID']) : '—';
                                ?>
                                    <tr data-status="<?= $u['status'] ?>" data-access="<?= $u['access'] === 'unlimited' ? 'unlimited' : 'single' ?>">
                                        <td style="color:var(--text-400);font-size:12px;"><?= $i+1 ?></td>
                                        <td>
                                            <span class="key-cell" onclick="copyText('<?= htmlspecialchars($u['KeyAuth']) ?>', this)" title="Click to copy">
                                                <?= htmlspecialchars($u['KeyAuth']) ?>
                                            </span>
                                        </td>
                                        <td>
                                            <?php if ($u['status'] === 'active'): ?>
                                            <span class="badge badge-active"><span class="dot-sm"></span> Active</span>
                                            <?php else: ?>
                                            <span class="badge badge-inactive"><span class="dot-sm"></span> Inactive</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if ($u['access'] === 'unlimited'): ?>
                                            <span class="badge badge-unlimited"><i class="fas fa-infinity"></i> Unlimited</span>
                                            <?php else: ?>
                                            <span class="badge badge-single"><i class="fas fa-mobile-alt"></i> Single</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if ($u['deviceID']): ?>
                                            <span title="<?= htmlspecialchars($u['deviceID']) ?>" style="font-size:12px;color:var(--text-400);">
                                                <i class="fas fa-mobile-alt"></i> <?= htmlspecialchars($deviceShort) ?>
                                            </span>
                                            <?php else: ?>
                                            <span style="color:var(--text-400);font-size:12px;">—</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if (!$tr): ?>
                                            <span style="color:var(--text-400);font-size:12px;">Never</span>
                                            <?php elseif ($tr['expired']): ?>
                                            <span class="badge badge-expired"><i class="fas fa-skull"></i> Expired</span>
                                            <?php else: ?>
                                            <span style="font-size:12px;color:var(--text-500);"><?= $tr['text'] ?></span>
                                            <?php endif; ?>
                                        </td>
                                        <td style="font-size:12px;color:var(--text-400);"><?= date('d M Y', strtotime($u['registeredDate'])) ?></td>
                                        <td style="text-align:right;">
                                            <div class="action-group" style="justify-content:flex-end;">
                                                <button class="action-btn edit" onclick='openEditModal(<?= json_encode($u) ?>)' title="Edit"><i class="fas fa-pen"></i></button>
                                                <button class="action-btn toggle" onclick="toggleStatus(<?= $u['id'] ?>)" title="Toggle Status"><i class="fas fa-power-off"></i></button>
                                                <button class="action-btn delete" onclick="deleteKey(<?= $u['id'] ?>, '<?= htmlspecialchars($u['KeyAuth']) ?>')" title="Delete"><i class="fas fa-trash"></i></button>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                                <?php if(empty($users)): ?>
                                    <tr><td colspan="8">
                                        <div class="empty-state">
                                            <i class="fas fa-key"></i>
                                            <h4>No keys found</h4>
                                            <p>Create your first key in the "Create Key" section</p>
                                        </div>
                                    </td></tr>
                                <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div><!-- /tab-keys -->

            <!-- ==============================
                 TAB: CREATE KEY
                 ============================== -->
            <div id="tab-create" class="tab-pane" style="display:none;">
                <div class="create-grid">

                    <!-- Create Form -->
                    <div class="panel">
                        <div class="panel-header">
                            <div class="panel-title">
                                <i class="fas fa-plus-circle"></i> Create New Key
                            </div>
                        </div>
                        <div class="panel-body">
                            <form method="POST" id="createForm">

                                <div class="fg">
                                    <label>Key Generator</label>
                                    <div class="key-gen">
                                        <div class="key-display" id="genKeyDisplay">________</div>
                                        <button type="button" class="icon-btn" onclick="copyKey()" title="Copy key"><i class="fas fa-copy"></i></button>
                                    </div>
                                    <button type="button" class="btn btn-primary btn-sm" onclick="generateKey()" style="margin-top:4px;">
                                        <i class="fas fa-bolt"></i> Generate New Key
                                    </button>
                                </div>

                                <div class="fg">
                                    <label>Key Auth <span style="color:var(--text-400);font-weight:400;text-transform:none;letter-spacing:0;">(8 characters)</span></label>
                                    <input type="text" name="keyAuth" id="keyAuthInput" maxlength="8" minlength="8"
                                           placeholder="XXXXXXXX" required class="key-input">
                                </div>

                                <div class="form-grid">
                                    <div class="fg">
                                        <label>Access Type</label>
                                        <select name="access">
                                            <option value="single">Single Device</option>
                                            <option value="unlimited">Unlimited Devices</option>
                                        </select>
                                    </div>
                                    <div class="fg">
                                        <label>Status</label>
                                        <select name="status">
                                            <option value="active">Active</option>
                                            <option value="inactive">Inactive</option>
                                        </select>
                                    </div>
                                    <div class="fg span2">
                                        <label>Valid Until</label>
                                        <input type="datetime-local" name="validUntil">
                                        <div class="hint">Leave empty for no expiry</div>
                                    </div>
                                </div>

                                <button type="submit" name="create_user" class="btn btn-primary btn-full" style="margin-top:4px;">
                                    <i class="fas fa-plus"></i> Create Key
                                </button>
                            </form>
                        </div>
                    </div>

                    <!-- Side Info -->
                    <div style="display:flex;flex-direction:column;gap:16px;">

                        <!-- Key Format -->
                        <div class="panel">
                            <div class="panel-header">
                                <div class="panel-title">
                                    <i class="fas fa-info-circle"></i> Key Format
                                </div>
                            </div>
                            <div class="panel-body">
                                <p style="font-size:13px;color:var(--text-500);margin-bottom:14px;">
                                    Keys are <strong style="color:var(--text-900);">8 characters</strong>, alphanumeric (auto-uppercase).
                                </p>
                                <div class="key-examples">
                                    <?php foreach(['7C5I8ZTT','UO8PEGVI','A9F7KL2Q'] as $ex): ?>
                                    <div class="key-example-row">
                                        <div class="key-pill"><?= $ex ?></div>
                                        <button class="btn btn-outline btn-sm" onclick="useKey('<?= $ex ?>')">
                                            <i class="fas fa-arrow-right"></i> Use
                                        </button>
                                    </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>

                        <!-- Quick Stats -->
                        <div class="panel">
                            <div class="panel-header">
                                <div class="panel-title">
                                    <i class="fas fa-chart-pie"></i> Quick Stats
                                </div>
                            </div>
                            <div class="panel-body">
                                <div class="qs-list">
                                    <div class="qs-row"><span>Total Keys</span><span><?= $total ?></span></div>
                                    <div class="qs-row"><span>Active</span><span style="color:var(--green);"><?= $active ?></span></div>
                                    <div class="qs-row"><span>Inactive</span><span style="color:var(--text-400);"><?= $inactive_count ?></span></div>
                                    <div class="qs-row"><span>Expired</span><span style="color:var(--red);"><?= $expired ?></span></div>
                                    <div class="qs-row"><span>Unlimited</span><span style="color:var(--amber);"><?= $unlimitedCount ?></span></div>
                                    <div class="qs-row"><span>Single Device</span><span style="color:var(--blue);"><?= $singleCount ?></span></div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div><!-- /tab-create -->

        </div><!-- /content-area -->
    </div><!-- /main-content -->
</div><!-- /admin-wrapper -->

<!-- ==============================
     EDIT MODAL
     ============================== -->
<div class="overlay" id="editModal">
    <div class="modal">
        <div class="modal-header">
            <h3><i class="fas fa-pen"></i> Edit Key</h3>
            <button class="close-btn" onclick="closeModal()"><i class="fas fa-times"></i></button>
        </div>
        <form method="POST">
            <div class="modal-body">
                <input type="hidden" name="user_id" id="editUserId">

                <div class="fg">
                    <label>Key Auth</label>
                    <input type="text" id="editKeyAuth" disabled class="key-input"
                           style="background:var(--red-soft);color:var(--red);border-color:var(--red-border);">
                </div>

                <div class="form-grid">
                    <div class="fg">
                        <label>Access Type</label>
                        <select name="access" id="editAccess">
                            <option value="single">Single Device</option>
                            <option value="unlimited">Unlimited</option>
                        </select>
                    </div>
                    <div class="fg">
                        <label>Status</label>
                        <select name="status" id="editStatus">
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                        </select>
                    </div>
                    <div class="fg span2">
                        <label>Valid Until</label>
                        <input type="datetime-local" name="validUntil" id="editValidUntil">
                    </div>
                </div>

                <label class="check-row">
                    <input type="checkbox" name="reset_device" id="editResetDevice">
                    <span>Reset device lock (clear bound device)</span>
                </label>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline" onclick="closeModal()">Cancel</button>
                <button type="submit" name="update_user" class="btn btn-primary">
                    <i class="fas fa-save"></i> Save Changes
                </button>
            </div>
        </form>
    </div>
</div>

<script>
// ===== TAB SWITCHING =====
const tabTitles = { dashboard: 'Overview', keys: 'All Keys', create: 'Create Key' };

function switchTab(name) {
    document.querySelectorAll('.tab-pane').forEach(p => { p.style.display = 'none'; p.classList.remove('active'); });
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));

    const pane = document.getElementById('tab-' + name);
    if (pane) { pane.style.display = 'block'; pane.classList.add('active'); }

    const nav = document.querySelector(`.nav-item[data-tab="${name}"]`);
    if (nav) nav.classList.add('active');

    document.getElementById('pageTitle').innerHTML = '<span>#</span> ' + (tabTitles[name] || name);
    document.getElementById('sidebar').classList.remove('open');
}

// ===== KEY GENERATOR =====
function generateKey() {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let key = '';
    for (let i = 0; i < 8; i++) key += chars[Math.floor(Math.random() * chars.length)];
    document.getElementById('genKeyDisplay').textContent = key;
    document.getElementById('keyAuthInput').value = key;
}

function useKey(key) {
    document.getElementById('keyAuthInput').value = key;
    switchTab('create');
}

function copyKey() {
    const val = document.getElementById('genKeyDisplay').textContent.trim();
    if (val && val !== '________') {
        navigator.clipboard.writeText(val).then(() => {
            const btn = document.querySelector('.key-gen .icon-btn');
            const orig = btn.innerHTML;
            btn.innerHTML = '<i class="fas fa-check" style="color:var(--green);"></i>';
            setTimeout(() => btn.innerHTML = orig, 1500);
        });
    }
}

function copyText(text, el) {
    navigator.clipboard.writeText(text).then(() => {
        const orig = el.style.color;
        el.style.color = 'var(--green)';
        setTimeout(() => el.style.color = orig, 1500);
    });
}

// ===== EDIT MODAL =====
function openEditModal(user) {
    document.getElementById('editUserId').value = user.id;
    document.getElementById('editKeyAuth').value = user.KeyAuth;
    document.getElementById('editAccess').value = user.access;
    document.getElementById('editStatus').value = user.status;
    document.getElementById('editResetDevice').checked = false;

    if (user.validUntil && user.validUntil !== '0000-00-00 00:00:00') {
        try {
            const d = new Date(user.validUntil.replace(' ', 'T'));
            if (!isNaN(d.getTime())) {
                const pad = n => String(n).padStart(2, '0');
                document.getElementById('editValidUntil').value =
                    `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
            } else { document.getElementById('editValidUntil').value = ''; }
        } catch(e) { document.getElementById('editValidUntil').value = ''; }
    } else {
        document.getElementById('editValidUntil').value = '';
    }

    document.getElementById('editModal').classList.add('open');
}

function closeModal() { document.getElementById('editModal').classList.remove('open'); }

document.getElementById('editModal').addEventListener('click', function(e) {
    if (e.target === this) closeModal();
});

// ===== TOGGLE STATUS =====
function toggleStatus(id) {
    if (confirm('Toggle status for this key?')) window.location.href = '?toggle=' + id;
}

// ===== DELETE KEY =====
function deleteKey(id, key) {
    if (confirm(`Delete key "${key}"?\nThis action cannot be undone.`)) window.location.href = '?delete=' + id;
}

// ===== TABLE FILTER =====
function filterTable() {
    const search = document.getElementById('searchInput').value.toLowerCase();
    const status = document.getElementById('statusFilter').value;
    const access = document.getElementById('accessFilter').value;
    const rows   = document.querySelectorAll('#keysBody tr');
    let visible  = 0;

    rows.forEach(row => {
        if (row.cells) {
            const text      = row.textContent.toLowerCase();
            const rowStatus = row.dataset.status || '';
            const rowAccess = row.dataset.access  || '';
            const show = (!search || text.includes(search))
                      && (!status || rowStatus === status)
                      && (!access || rowAccess === access);
            row.style.display = show ? '' : 'none';
            if (show) visible++;
        }
    });

    document.getElementById('tableCount').textContent = visible + ' key' + (visible !== 1 ? 's' : '');
}

// ===== INIT =====
document.addEventListener('DOMContentLoaded', generateKey);
document.addEventListener('keydown', e => { if (e.key === 'Escape') closeModal(); });
</script>
<?php endif; ?>
</body>
</html>
